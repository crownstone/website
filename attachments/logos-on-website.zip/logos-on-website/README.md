# Logo

See styleguide at https://crownstone.rocks/presskit. 

## Usage

Use the black on white logo which has a transparent background. Use the .ai or .svg format which has vector graphics. This scales towards the dimensions required. Use of the .png or .jpeg is discouraged but added for your convenience in rare cases.

Do not use the white on blue (#003e52) logo except if really necessary.
